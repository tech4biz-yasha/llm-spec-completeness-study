# Kit vs Raw SRS — controlled experiment

One module, two inputs, same model, same tests. Meridian exit workflow.

## Protocol
- Tool: Cursor (or Claude Code), same model both sides, default settings
- Fresh session per run. No memory, no project context, no other files open.
- 3 runs per side: A1 A2 A3 (raw SRS), B1 B2 B3 (kit)
- Prompt is fixed (below). No mid-run coaching. If the agent asks a question:
  Run A -> answer in one line, the way a busy developer would.
  Run B -> reply only: "follow the kit".
  Log every such exchange in interventions.md.
- Stop condition: agent says it is done, or 30 minutes, whichever first.

## Fixed prompt (both sides, verbatim)
"Implement the tenant exit workflow backend module in Python 3.12 with FastAPI
and SQLAlchemy against PostgreSQL. Cover initiation through completion including
deposit settlement and NOC issuance. Write it production grade. The specification
is in the attached files. When complete, list what you built."

## Measurements per run
1. tokens in / tokens out (from tool usage panel)
2. wall clock minutes
3. number of user prompts sent (including the first)
4. acceptance tests passed (run scoring/test_exit_workflow.py against the code)
5. invented decisions (score with scoring/invented-decisions-checklist.md)
6. blockers raised vs silently resolved

## Drift check (after all runs)
Compare A1/A2/A3 to each other on the 10 checklist points. Count how many
points got 2+ different answers across the three runs. Same for B. That pair
of numbers is the determinism result.
